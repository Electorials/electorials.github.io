electorials.com

Company shoutouts will go on *Company Reviews* page, with a dedicated section to those companies given shoutouts.
URLs might be prefixed or suffixed with "shoutout", but will still follow the /review/company/*company-review* scheme.
